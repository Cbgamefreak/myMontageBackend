

$("#new-user").on("click", function(){
    console.log("test")
    console.log("this works")
    var nameInput = $("#user-name").val().trim()

    var userNameObject ={
        name:nameInput
    }
    console.log(nameInput)
    event.preventDefault();
    // Don't do anything if the name fields hasn't been filled out
    if (nameInput = "") {
      console.log("there is no name")
    }
    
    // Calling the upsertNewUser function and passing in the value of the name input
    window.location.href = "/login"
    
    upsertNewUser(userNameObject);

   
});


  function upsertNewUser(NewUserData) {
      console.log(NewUserData)
    $.post("/api/authors", NewUserData)
      .then( 
        console.log("this works2")
        //window.location.href = "/login")
      )}