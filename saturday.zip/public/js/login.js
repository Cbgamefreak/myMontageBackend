var currentUserName;


$( ".login-button").on("click", function(){
currentUserName = $(".usernameVal").val().trim()
console.log(currentUserName)
localStorage.setItem("user", currentUserName)
window.location.href = "/profile";
})

//localstorage.removeItme("user");



